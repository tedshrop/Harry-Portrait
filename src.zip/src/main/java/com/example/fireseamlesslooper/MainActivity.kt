package com.example.fireseamlesslooper

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.view.TextureView
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import com.example.fireseamlesslooper.usb.UsbAccessManager
import com.example.fireseamlesslooper.usb.UsbState
import com.example.fireseamlesslooper.video.VideoPlaybackController

class MainActivity : AppCompatActivity() {

    private val TAG = "USB_SAF_DEBUG"
    private lateinit var statusText: TextView
    private lateinit var usbPickerButton: Button

    // USB picker result activity code
    private val REQUEST_USB_TREE = 1001

    // Core managers
    private lateinit var usbAccessManager: UsbAccessManager
    private lateinit var videoController: VideoPlaybackController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "onCreate")
        hideSystemUI()
        setContentView(R.layout.activity_main)

        // Initialize UI components
        statusText = findViewById(R.id.statusText)
        usbPickerButton = findViewById(R.id.usbPickerButton)

        // Initialize managers
        usbAccessManager = UsbAccessManager(this)
        videoController = VideoPlaybackController(application, usbAccessManager)

        // Initialize players and managers
        videoController.initializePlayer()
        usbAccessManager.initialize()

        // Observe video controller status
        videoController.statusText.observe(this, Observer { text ->
            setStatusText(text ?: "")
        })

        // Set up USB picker button
        usbPickerButton.setOnClickListener {
            Log.d(TAG, "USB picker button clicked")
            usbAccessManager.requestUsbRoot(this)
            // Update UI after picker request (initially show "Please select")
            updateUIForUsbState(UsbState.NoPermission)
        }

        // Note: USB state changes are handled via broadcast-style updates
        // rather than continuous observation due to environment constraints

        // Attach player to texture view
        val textureView = findViewById<TextureView>(R.id.textureView)
        textureView.rotation = 90f

        // Perform explicit initial UI state setup based on USB status
        initializeUIState()

        Log.d(TAG, "MainActivity initialization complete")
    }

    /**
     * Set up initial UI state based on USB availability
     */
    private fun initializeUIState() {
        // Check current USB state and show appropriate UI
        val currentState = usbAccessManager.usbState.value
        Log.d(TAG, "Initial USB state: $currentState")

        updateUIForUsbState(currentState)

        // If no USB is configured, explicitly show picker button
        if (currentState is UsbState.NoPermission || currentState is UsbState.Unavailable) {
            setStatusText("Please select USB drive\nTap 'SELECT USB' button below")
            usbPickerButton.visibility = android.view.View.VISIBLE
        }
    }

    private fun setStatusText(text: String) {
        Log.d(TAG, "setStatusText: $text")
        if (text.isEmpty()) {
            statusText.visibility = android.view.View.GONE
        } else {
            statusText.text = text
            statusText.visibility = android.view.View.VISIBLE
        }
    }

    private fun hideSystemUI() {
        window.decorView.systemUiVisibility =
            (android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                    or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        actionBar?.hide()
    }

    /**
     * Update UI based on USB state
     */
    private fun updateUIForUsbState(state: UsbState) {
        when (state) {
            UsbState.NoPermission -> {
                setStatusText("Please select USB drive")
                usbPickerButton.visibility = android.view.View.VISIBLE
            }
            UsbState.Searching -> {
                setStatusText("Looking for USB drive...")
                usbPickerButton.visibility = android.view.View.VISIBLE
            }
            is UsbState.Available -> {
                setStatusText("USB connected and ready")
                usbPickerButton.visibility = android.view.View.GONE
            }
            UsbState.Unavailable -> {
                setStatusText("USB drive disconnected")
                usbPickerButton.visibility = android.view.View.VISIBLE
            }
        }
    }

    /**
     * Handle USB picker result
     */
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_USB_TREE) {
            Log.d(TAG, "Received USB picker result: ${resultCode == Activity.RESULT_OK}")
            usbAccessManager.handlePickerResult(requestCode, resultCode, data)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d(TAG, "Permission granted")
            } else {
                setStatusText("Storage permission required. Please grant in settings.")
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        usbAccessManager.dispose()
        videoController.releasePlayer()
        Log.d(TAG, "MainActivity destroyed")
    }
}
