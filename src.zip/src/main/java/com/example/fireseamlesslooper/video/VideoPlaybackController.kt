package com.example.fireseamlesslooper.video

import android.app.Application
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.example.fireseamlesslooper.usb.UsbAccessManager
import com.example.fireseamlesslooper.usb.UsbState
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.PlaybackException

class VideoPlaybackController(
    private val application: Application,
    private val usbAccessManager: UsbAccessManager
) {

    private val TAG = "VIDEO_CONTROLLER"
    val videoRepository = VideoRepository(usbAccessManager)
    var exoPlayer: ExoPlayer? = null

    val statusText = MutableLiveData<String>("Initializing...")

    private var isInitialized = false

    fun initializePlayer() {
        if (isInitialized) return

        exoPlayer = ExoPlayer.Builder(application).build().apply {
            addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    when (state) {
                        Player.STATE_ENDED -> {
                            playNextVideo()
                        }
                        Player.STATE_READY -> {
                            statusText.value = ""
                        }
                        Player.STATE_BUFFERING -> {
                            statusText.value = "Buffering..."
                        }
                    }
                }

                override fun onPlayerError(error: PlaybackException) {
                    val errorMsg = "Video error: ${error.message}"
                    Log.e(TAG, errorMsg, error)
                    statusText.value = "Video playback error"

                    // Retry after 5 seconds
                    Handler(Looper.getMainLooper()).postDelayed({
                        statusText.value = "Retrying..."
                        playNextVideo()
                    }, 5000)
                }
            })
        }

        // Note: USB state is checked directly when needed, not observed continuously
        Log.d(TAG, "VideoPlaybackController initialized without continuous USB observation")

        isInitialized = true
        Log.d(TAG, "VideoPlaybackController initialized")
    }

    private fun handleUsbStateChange(state: UsbState) {
        when (state) {
            UsbState.NoPermission -> {
                exoPlayer?.pause()
                statusText.value = "Please select USB drive"
                Log.d(TAG, "USB access not granted")
            }
            UsbState.Searching -> {
                statusText.value = "Looking for USB drive..."
                Log.d(TAG, "Searching for USB")
            }
            is UsbState.Available -> {
                val videoCount = usbAccessManager.getTotalVideoCount()
                statusText.value = "USB ready with $videoCount videos"
                Log.d(TAG, "USB available with $videoCount videos")
                playNextVideo()
            }
            UsbState.Unavailable -> {
                exoPlayer?.pause()
                statusText.value = "USB drive disconnected"
                Log.d(TAG, "USB became unavailable")
            }
        }
    }

    private fun playNextVideo() {
        if (!videoRepository.hasVideos()) {
            statusText.value = "No videos found in USB folders"
            Log.w(TAG, "No videos available for playback")
            return
        }

        val videoUri = videoRepository.nextVideo()
        if (videoUri != null) {
            Log.d(TAG, "Playing video from SAF URI: $videoUri")
            val mediaItem = MediaItem.fromUri(videoUri)
            exoPlayer?.setMediaItem(mediaItem)
            exoPlayer?.prepare()
            exoPlayer?.play()
        } else {
            statusText.value = "No more videos available"
            Log.w(TAG, "No video selected for playback")
        }
    }

    /**
     * Manually trigger video selection and playback
     */
    fun playNextVideoManually() {
        if (usbAccessManager.usbState.value.isAvailable()) {
            statusText.value = ""
            playNextVideo()
        } else {
            Log.w(TAG, "Cannot play next video - USB not available")
        }
    }

    /**
     * Pause current playback
     */
    fun pausePlayback() {
        exoPlayer?.pause()
        statusText.value = "Playback paused"
    }

    /**
     * Resume playback
     */
    fun resumePlayback() {
        if (usbAccessManager.usbState.value.isAvailable()) {
            exoPlayer?.play()
            statusText.value = ""
        }
    }

    fun releasePlayer() {
        exoPlayer?.release()
        exoPlayer = null
        Log.d(TAG, "Player released")
    }
}
