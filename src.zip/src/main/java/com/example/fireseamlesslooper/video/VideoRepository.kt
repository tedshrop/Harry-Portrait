package com.example.fireseamlesslooper.video

import android.net.Uri
import android.util.Log
import androidx.documentfile.provider.DocumentFile
import com.example.fireseamlesslooper.usb.UsbAccessManager
import com.example.fireseamlesslooper.usb.UsbState

class VideoRepository(private val usbAccessManager: UsbAccessManager) {

    private val TAG = "VIDEO_REPO"

    /**
     * Get the next video URI using weighted selection from categorized videos
     */
    fun nextVideo(): Uri? {
        if (!usbAccessManager.usbState.value.isAvailable()) {
            Log.w(TAG, "USB not available for video selection")
            return null
        }

        try {
            val categorizedVideos = usbAccessManager.getCachedVideos()
            if (categorizedVideos.isEmpty()) {
                Log.w(TAG, "No categorized videos available")
                return null
            }

            val selectedVideo = selectWeightedVideo(categorizedVideos)
            Log.d(TAG, "Selected video: ${selectedVideo?.name}")
            return selectedVideo?.uri
        } catch (e: Exception) {
            Log.e(TAG, "Error selecting next video: ${e.message}", e)
            return null
        }
    }

    /**
     * Check if videos are available
     */
    fun hasVideos(): Boolean {
        return try {
            usbAccessManager.getTotalVideoCount() > 0
        } catch (e: Exception) {
            Log.e(TAG, "Error checking videos: ${e.message}", e)
            false
        }
    }

    /**
     * Get total video count
     */
    fun getTotalVideoCount(): Int {
        return usbAccessManager.getTotalVideoCount()
    }

    /**
     * Select a video using weighted random selection based on categories
     */
    private fun selectWeightedVideo(categorizedVideos: Map<String, List<DocumentFile>>): DocumentFile? {
        if (categorizedVideos.isEmpty()) return null

        // Category weights (matching the original implementation)
        val folderWeights = mapOf(
            "common" to 60,
            "uncommon" to 25,
            "rare" to 10,
            "legendary" to 5
        )

        // Filter to only categories that have videos
        val availableCategories = categorizedVideos.filter { it.value.isNotEmpty() }

        if (availableCategories.isEmpty()) return null

        // Calculate total weight
        val totalWeight = availableCategories.keys.sumOf { folderWeights[it] ?: 0 }
        if (totalWeight <= 0) return null

        // Pick weighted category
        val randomValue = kotlin.random.Random.nextInt(totalWeight)
        var cumulativeWeight = 0

        var selectedCategory: String? = null
        for ((category, videos) in availableCategories) {
            val weight = folderWeights[category] ?: 0
            cumulativeWeight += weight
            if (randomValue < cumulativeWeight) {
                selectedCategory = category
                break
            }
        }

        // Return random video from the selected category
        val categoryVideos = selectedCategory?.let { categorizedVideos[it] }
        return categoryVideos?.randomOrNull().also { selected ->
            if (selected != null) {
                Log.d(TAG, "Selected '${selected.name}' from category '$selectedCategory'")
            }
        }
    }
}
