package com.example.fireseamlesslooper.usb

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.util.Log
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

sealed class UsbState {
    object NoPermission : UsbState()
    object Searching : UsbState()
    data class Available(val root: DocumentFile) : UsbState()
    object Unavailable : UsbState()

    fun isAvailable(): Boolean = this is Available
    fun hasPermission(): Boolean = this != NoPermission
}

class UsbAccessManager(
    private val context: Context,
    private val uriStore: UsbUriStore = UsbUriStore(context),
    private val videoScanner: UsbVideoScanner = UsbVideoScanner()
) {

    companion object {
        private const val TAG = "USB_SAF_DEBUG"
        private const val REQ_USB_TREE = 1001
        private const val WATCHER_INTERVAL_MS = 4000L // 4 seconds polling
    }

    private val _usbState = MutableStateFlow<UsbState>(UsbState.NoPermission)
    val usbState: StateFlow<UsbState> = _usbState.asStateFlow()

    // Current cached video data
    private var cachedVideos: Map<String, List<DocumentFile>> = emptyMap()
    private var cachedCurrentRoot: DocumentFile? = null

    // Watcher job for background monitoring
    private var watcherJob: Job? = null
    private var isInitialized = false

    /**
     * Initialize the USB access manager and start monitoring
     */
    fun initialize() {
        if (isInitialized) return

        Log.d(TAG, "Initializing UsbAccessManager")
        isInitialized = true

        // Check for stored URI on startup
        val storedUri = uriStore.get()
        if (storedUri != null) {
            _usbState.value = UsbState.Searching
            startWatching()
        } else {
            _usbState.value = UsbState.NoPermission
        }
    }

    /**
     * Launch the USB document tree picker with Fire OS compatible configuration
     */
    fun requestUsbRoot(activity: Activity) {
        Log.d(TAG, "Requesting USB root via document picker (Fire OS compatible)")

        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            // REQUIRED for Fire OS to show USB OTG drives
            putExtra("android.provider.extra.SHOW_ADVANCED", true)

            // REQUIRED to open the storage provider root instead of Downloads
            val initial = DocumentsContract.buildRootsUri("com.android.externalstorage.documents")
            putExtra(DocumentsContract.EXTRA_INITIAL_URI, initial)

            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }

        try {
            activity.startActivityForResult(intent, REQ_USB_TREE)
            Log.d(TAG, "Started USB document picker with minimal config")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start USB picker: ${e.message}", e)
            // Could fall back to a different approach here if needed
        }
    }

    /**
     * Handle the result from the USB document picker
     */
    fun handlePickerResult(requestCode: Int, resultCode: Int, data: Intent?): Boolean {
        if (requestCode != REQ_USB_TREE || resultCode != Activity.RESULT_OK) {
            Log.d(TAG, "USB picker cancelled or failed")
            return false
        }

        return data?.data?.let { uri ->
            try {
                Log.d(TAG, "USB picker returned URI: $uri")

                // Take persistable permission
                val flags = data.flags and (
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                )

                context.contentResolver.takePersistableUriPermission(uri, flags)

                // Store the URI
                uriStore.save(uri.toString())

                // Update state and start watching
                _usbState.value = UsbState.Searching
                startWatching()

                Log.d(TAG, "USB permission granted and stored")
                true
            } catch (e: Exception) {
                Log.e(TAG, "Error handling USB picker result: ${e.message}", e)
                false
            }
        } ?: false
    }

    /**
     * Start the background USB watcher
     */
    private fun startWatching() {
        watcherJob?.cancel()

        watcherJob = CoroutineScope(Dispatchers.IO).launch {
            while (isActive) {
                try {
                    checkUsbAccessibility()
                    delay(WATCHER_INTERVAL_MS)
                } catch (e: Exception) {
                    Log.e(TAG, "Error in USB watcher: ${e.message}", e)
                    delay(WATCHER_INTERVAL_MS)
                }
            }
        }

        Log.d(TAG, "Started USB watcher with ${WATCHER_INTERVAL_MS}ms interval")
    }

    /**
     * Stop the background USB watcher
     */
    fun stopWatching() {
        watcherJob?.cancel()
        watcherJob = null
        Log.d(TAG, "Stopped USB watcher")
    }

    /**
     * Check current USB accessibility and update state
     */
    private fun checkUsbAccessibility() {
        val storedUriString = uriStore.get()

        if (storedUriString == null) {
            updateState(UsbState.NoPermission)
            return
        }

        try {
            val uri = Uri.parse(storedUriString)
            val root = DocumentFile.fromTreeUri(context, uri)

            if (root != null && root.exists() && root.canRead()) {
                try {
                    // Try to list files to ensure full access
                    root.listFiles()
                    updateState(UsbState.Available(root))
                } catch (e: Exception) {
                    Log.w(TAG, "USB root accessible but listFiles failed: ${e.message}")
                    updateState(UsbState.Unavailable)
                }
            } else {
                Log.w(TAG, "USB document not accessible: root=$root, exists=${root?.exists()}, canRead=${root?.canRead()}")
                updateState(UsbState.Unavailable)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error checking USB accessibility: ${e.message}", e)
            updateState(UsbState.Unavailable)
        }
    }

    /**
     * Update the USB state and handle state transitions
     */
    private fun updateState(newState: UsbState) {
        val oldState = _usbState.value

        if (oldState::class != newState::class) {
            Log.d(TAG, "USB state changed: $oldState -> $newState")
            _usbState.value = newState

            // Handle state-specific actions
            when (newState) {
                is UsbState.Available -> {
                    onUsbAvailable(newState.root)
                }
                is UsbState.Unavailable -> {
                    onUsbUnavailable()
                }
                else -> {} // No special handling needed
            }
        }
    }

    /**
     * Called when USB becomes available
     */
    private fun onUsbAvailable(root: DocumentFile) {
        cachedCurrentRoot = root
        try {
            cachedVideos = videoScanner.scanVideos(root)
            val totalVideos = videoScanner.getTotalVideoCount(cachedVideos)
            Log.d(TAG, "USB available with $totalVideos videos across ${cachedVideos.size} categories")
        } catch (e: Exception) {
            Log.e(TAG, "Error scanning videos on USB available: ${e.message}", e)
        }
    }

    /**
     * Called when USB becomes unavailable
     */
    private fun onUsbUnavailable() {
        cachedCurrentRoot = null
        cachedVideos = emptyMap()
        Log.d(TAG, "USB became unavailable, cleared cache")
    }

    /**
     * Get currently cached videos by category
     */
    fun getCachedVideos(): Map<String, List<DocumentFile>> = cachedVideos

    /**
     * Get flattened list of all videos
     */
    fun getAllVideos(): List<DocumentFile> = videoScanner.getAllVideos(cachedVideos)

    /**
     * Get total video count
     */
    fun getTotalVideoCount(): Int = videoScanner.getTotalVideoCount(cachedVideos)

    /**
     * Clear all stored USB permissions and data
     */
    fun clearPermissions() {
        try {
            cachedCurrentRoot?.uri?.let { uri ->
                context.contentResolver.releasePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing permissions: ${e.message}", e)
        }

        uriStore.clear()
        cachedCurrentRoot = null
        cachedVideos = emptyMap()
        updateState(UsbState.NoPermission)
        Log.d(TAG, "Cleared all USB permissions and data")
    }

    /**
     * Clean up resources
     */
    fun dispose() {
        stopWatching()
        Log.d(TAG, "UsbAccessManager disposed")
    }
}
